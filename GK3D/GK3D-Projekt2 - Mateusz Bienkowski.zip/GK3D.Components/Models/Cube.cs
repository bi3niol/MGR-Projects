﻿using GK3D.Components.Shaders;
using Microsoft.Xna.Framework;

namespace GK3D.Components.Models
{
    public class Cube : CustomModel<VertexPositionColorNormal>
    {
        public float a { get; set; }
        public Cube(GraphicsDeviceManager graphics, SimpleEffect effect, float size, Color color) : base(effect)
        {
            a = size;
            Vertices = new VertexPositionColorNormal[36];
            var Size = new Vector3(size);
           
            Vector3 topLeftFront = new Vector3(-1.0f, 1.0f, -1.0f) * Size;
            Vector3 topLeftBack = new Vector3(-1.0f, 1.0f, 1.0f) * Size;
            Vector3 topRightFront = new Vector3(1.0f, 1.0f, -1.0f) * Size;
            Vector3 topRightBack = new Vector3(1.0f, 1.0f, 1.0f) * Size;

            // Calculate the position of the vertices on the bottom face.
            Vector3 btmLeftFront = new Vector3(-1.0f, -1.0f, -1.0f) * Size;
            Vector3 btmLeftBack = new Vector3(-1.0f, -1.0f, 1.0f) * Size;
            Vector3 btmRightFront = new Vector3(1.0f, -1.0f, -1.0f) * Size;
            Vector3 btmRightBack = new Vector3(1.0f, -1.0f, 1.0f) * Size;

            // Normal vectors for each face (needed for lighting / display)
            Vector3 normalFront = new Vector3(0.0f, 0.0f, 1.0f);
            Vector3 normalBack = new Vector3(0.0f, 0.0f, -1.0f);
            Vector3 normalTop = new Vector3(0.0f, 1.0f, 0.0f);
            Vector3 normalBottom = new Vector3(0.0f, -1.0f, 0.0f);
            Vector3 normalLeft = new Vector3(-1.0f, 0.0f, 0.0f);
            Vector3 normalRight = new Vector3(1.0f, 0.0f, 0.0f);

            // UV texture coordinates
            Vector2 textureTopLeft = new Vector2(1.0f * Size.X, 0.0f * Size.Y);
            Vector2 textureTopRight = new Vector2(0.0f * Size.X, 0.0f * Size.Y);
            Vector2 textureBottomLeft = new Vector2(1.0f * Size.X, 1.0f * Size.Y);
            Vector2 textureBottomRight = new Vector2(0.0f * Size.X, 1.0f * Size.Y);

            // Add the vertices for the FRONT face.
            Vertices[0] = new VertexPositionColorNormal(topLeftFront, color, normalFront);
            Vertices[1] = new VertexPositionColorNormal(btmLeftFront, color, normalFront);
            Vertices[2] = new VertexPositionColorNormal(topRightFront, color, normalFront);
            Vertices[3] = new VertexPositionColorNormal(btmLeftFront, color, normalFront);
            Vertices[4] = new VertexPositionColorNormal(btmRightFront, color, normalFront);
            Vertices[5] = new VertexPositionColorNormal(topRightFront, color, normalFront);

            // Add the vertices for the BACK face.
            Vertices[6] = new VertexPositionColorNormal(topLeftBack, color, normalBack);
            Vertices[7] = new VertexPositionColorNormal(topRightBack, color, normalBack);
            Vertices[8] = new VertexPositionColorNormal(btmLeftBack, color, normalBack);
            Vertices[9] = new VertexPositionColorNormal(btmLeftBack, color, normalBack);
            Vertices[10] = new VertexPositionColorNormal(topRightBack, color, normalBack);
            Vertices[11] = new VertexPositionColorNormal(btmRightBack, color, normalBack);

            // Add the vertices for the TOP face.
            Vertices[12] = new VertexPositionColorNormal(topLeftFront, color, normalTop);
            Vertices[13] = new VertexPositionColorNormal(topRightBack, color, normalTop);
            Vertices[14] = new VertexPositionColorNormal(topLeftBack, color, normalTop);
            Vertices[15] = new VertexPositionColorNormal(topLeftFront, color, normalTop);
            Vertices[16] = new VertexPositionColorNormal(topRightFront, color, normalTop);
            Vertices[17] = new VertexPositionColorNormal(topRightBack, color, normalTop);

            // Add the vertices for the BOTTOM face. 
            Vertices[18] = new VertexPositionColorNormal(btmLeftFront, color, normalTop);
            Vertices[19] = new VertexPositionColorNormal(btmLeftBack, color, normalTop);
            Vertices[20] = new VertexPositionColorNormal(btmRightBack, color, normalTop);
            Vertices[21] = new VertexPositionColorNormal(btmLeftFront, color, normalTop);
            Vertices[22] = new VertexPositionColorNormal(btmRightBack, color, normalTop);
            Vertices[23] = new VertexPositionColorNormal(btmRightFront, color, normalBottom);

            // Add the vertices for the LEFT face.
            Vertices[24] = new VertexPositionColorNormal(topLeftFront, color, normalLeft);
            Vertices[25] = new VertexPositionColorNormal(btmLeftBack, color, normalLeft);
            Vertices[26] = new VertexPositionColorNormal(btmLeftFront, color, normalLeft);
            Vertices[27] = new VertexPositionColorNormal(topLeftBack, color, normalLeft);
            Vertices[28] = new VertexPositionColorNormal(btmLeftBack, color, normalLeft);
            Vertices[29] = new VertexPositionColorNormal(topLeftFront, color, normalLeft);

            // Add the vertices for the RIGHT face. 
            Vertices[30] = new VertexPositionColorNormal(topRightFront, color, normalRight);
            Vertices[31] = new VertexPositionColorNormal(btmRightFront, color, normalRight);
            Vertices[32] = new VertexPositionColorNormal(btmRightBack, color, normalRight);
            Vertices[33] = new VertexPositionColorNormal(topRightBack, color, normalRight);
            Vertices[34] = new VertexPositionColorNormal(topRightFront, color, normalRight);
            Vertices[35] = new VertexPositionColorNormal(btmRightBack, color, normalRight);

            //// Add the vertices for the FRONT face.
            //Vertexes[0] = new VertexPositionNormalTexture(topLeftFront, normalFront, textureTopLeft);
            //Vertexes[1] = new VertexPositionNormalTexture(btmLeftFront, normalFront, textureBottomLeft);
            //Vertexes[2] = new VertexPositionNormalTexture(topRightFront, normalFront, textureTopRight);
            //Vertexes[3] = new VertexPositionNormalTexture(btmLeftFront, normalFront, textureBottomLeft);
            //Vertexes[4] = new VertexPositionNormalTexture(btmRightFront, normalFront, textureBottomRight);
            //Vertexes[5] = new VertexPositionNormalTexture(topRightFront, normalFront, textureTopRight);

            //// Add the vertices for the BACK face.
            //Vertexes[6] = new VertexPositionNormalTexture(topLeftBack, normalBack, textureTopRight);
            //Vertexes[7] = new VertexPositionNormalTexture(topRightBack, normalBack, textureTopLeft);
            //Vertexes[8] = new VertexPositionNormalTexture(btmLeftBack, normalBack, textureBottomRight);
            //Vertexes[9] = new VertexPositionNormalTexture(btmLeftBack, normalBack, textureBottomRight);
            //Vertexes[10] = new VertexPositionNormalTexture(topRightBack, normalBack, textureTopLeft);
            //Vertexes[11] = new VertexPositionNormalTexture(btmRightBack, normalBack, textureBottomLeft);

            //// Add the vertices for the TOP face.
            //Vertexes[12] = new VertexPositionNormalTexture(topLeftFront, normalTop, textureBottomLeft);
            //Vertexes[13] = new VertexPositionNormalTexture(topRightBack, normalTop, textureTopRight);
            //Vertexes[14] = new VertexPositionNormalTexture(topLeftBack, normalTop, textureTopLeft);
            //Vertexes[15] = new VertexPositionNormalTexture(topLeftFront, normalTop, textureBottomLeft);
            //Vertexes[16] = new VertexPositionNormalTexture(topRightFront, normalTop, textureBottomRight);
            //Vertexes[17] = new VertexPositionNormalTexture(topRightBack, normalTop, textureTopRight);

            //// Add the vertices for the BOTTOM face. 
            //Vertexes[18] = new VertexPositionNormalTexture(btmLeftFront, normalBottom, textureTopLeft);
            //Vertexes[19] = new VertexPositionNormalTexture(btmLeftBack, normalBottom, textureBottomLeft);
            //Vertexes[20] = new VertexPositionNormalTexture(btmRightBack, normalBottom, textureBottomRight);
            //Vertexes[21] = new VertexPositionNormalTexture(btmLeftFront, normalBottom, textureTopLeft);
            //Vertexes[22] = new VertexPositionNormalTexture(btmRightBack, normalBottom, textureBottomRight);
            //Vertexes[23] = new VertexPositionNormalTexture(btmRightFront, normalBottom, textureTopRight);

            //// Add the vertices for the LEFT face.
            //Vertexes[24] = new VertexPositionNormalTexture(topLeftFront, normalLeft, textureTopRight);
            //Vertexes[25] = new VertexPositionNormalTexture(btmLeftBack, normalLeft, textureBottomLeft);
            //Vertexes[26] = new VertexPositionNormalTexture(btmLeftFront, normalLeft, textureBottomRight);
            //Vertexes[27] = new VertexPositionNormalTexture(topLeftBack, normalLeft, textureTopLeft);
            //Vertexes[28] = new VertexPositionNormalTexture(btmLeftBack, normalLeft, textureBottomLeft);
            //Vertexes[29] = new VertexPositionNormalTexture(topLeftFront, normalLeft, textureTopRight);

            //// Add the vertices for the RIGHT face. 
            //Vertexes[30] = new VertexPositionNormalTexture(topRightFront, normalRight, textureTopLeft);
            //Vertexes[31] = new VertexPositionNormalTexture(btmRightFront, normalRight, textureBottomLeft);
            //Vertexes[32] = new VertexPositionNormalTexture(btmRightBack, normalRight, textureBottomRight);
            //Vertexes[33] = new VertexPositionNormalTexture(topRightBack, normalRight, textureTopRight);
            //Vertexes[34] = new VertexPositionNormalTexture(topRightFront, normalRight, textureTopLeft);
            //Vertexes[35] = new VertexPositionNormalTexture(btmRightBack, normalRight, textureBottomRight);
        }
    }
}
