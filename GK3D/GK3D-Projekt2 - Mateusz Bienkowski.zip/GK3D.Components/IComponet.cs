﻿using Microsoft.Xna.Framework;

namespace GK3D.Components
{
    public interface IComponet
    {
    }
}